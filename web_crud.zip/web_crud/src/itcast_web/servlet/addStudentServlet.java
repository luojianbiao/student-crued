package itcast_web.servlet;

import itcast_domain.Student;
import itcast_service.StudentService;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

public class addStudentServlet extends HttpServlet {
    StudentService studentService ;
    @Override
    public void init() throws ServletException {
    studentService = new StudentService() ;
    }

    public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    request.setCharacterEncoding("UTF-8");
    response.setCharacterEncoding("UTF-8");
        Student student = new Student() ;
        String str = request.getParameter("id") ;
        student.setName(request.getParameter("name"));
        student.setAge(Integer.parseInt(request.getParameter("age")));
        if(hasLength(str)){
            studentService.update(Integer.valueOf(str),student);
        }else {
            studentService.savaStudent(student);
        }
        response.sendRedirect("ListStudentServlet");
    }
   public  boolean hasLength(String str){
        return (str!=null) ;
    }

}

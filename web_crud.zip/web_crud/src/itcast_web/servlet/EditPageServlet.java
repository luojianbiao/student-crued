package itcast_web.servlet;

import itcast_domain.Student;
import itcast_service.StudentService;

import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

public class EditPageServlet extends HttpServlet {
    private StudentService studentService ;

    @Override
    public void init() throws ServletException {
    studentService = new StudentService() ;
    }

    @Override
    public void service(ServletRequest req, ServletResponse res) throws ServletException, IOException {
        String id = req.getParameter("id") ;
        if(hasLength(id)){
            Student student = studentService.get(Integer.valueOf(id));
            req.setAttribute("editStudent", student);
        }
        req.getRequestDispatcher("WEB-INF/views/student/addStudent.jsp").forward(req,res);
    }
    public boolean hasLength(String str){
        boolean flag=(str!=null) ;
        return flag ;
    }
}

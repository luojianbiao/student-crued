package itcast_web.servlet;

import itcast_domain.Student;
import itcast_service.StudentService;
import javax.servlet.ServletException;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

public class DeletStudentServlet extends HttpServlet {
    private StudentService studentService ;
    @Override
    public void init() throws ServletException {
        studentService = new StudentService() ;
    }
    @Override
    public void service(HttpServletRequest requset, HttpServletResponse response) throws ServletException, IOException {
       int id = Integer.valueOf(requset.getParameter("id")) ;
       studentService.deletIdStudent(id);
       response.sendRedirect("ListStudentServlet");
    }

}

package itcast_web.servlet;

import itcast_dao.IStudenDao;
import itcast_dao.impl.StudentImplDao;
import itcast_domain.Student;
import itcast_service.StudentService;
import org.junit.Test;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

public class ListStudentServlet extends HttpServlet {
    private StudentService studentService ;
    @Override
    public void init() throws ServletException {
        studentService = new StudentService() ;
        super.init();
    }
    @Override
    public void service(HttpServletRequest requset, HttpServletResponse response) throws ServletException, IOException {
        List<Student> list = studentService.studentList() ;
        requset.setAttribute("students",list);
        requset.getRequestDispatcher("WEB-INF/views/student/StudentList.jsp").forward(requset,response);
    }
}

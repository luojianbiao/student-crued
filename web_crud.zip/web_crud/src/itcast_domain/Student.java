/**
 * FileName: Student
 * Author:   10374
 * Date:     2019/7/10 10:14
 * Description: 学生实体类
 * Version:
 */
package itcast_domain;

/**
 * 〈一句话功能简述〉<br> 
 * 〈学生实体类〉
 */
public class Student {
    private long id ;
    private String name ;
    private Integer age ;

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer getAge() {
        return age;
    }

    public void setAge(Integer age) {
        this.age = age;
    }
}
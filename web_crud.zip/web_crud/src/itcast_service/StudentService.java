/**
 * FileName: StudentService
 * Author:   10374
 * Date:     2019/7/10 12:04
 * Description: 学生业务逻辑层
 * Version:
 */
package itcast_service;

import itcast_dao.IStudenDao;
import itcast_dao.impl.StudentImplDao;
import itcast_domain.Student;

import java.util.List;

/**
 * 〈一句话功能简述〉<br> 
 * 〈学生业务逻辑层〉
 */
public class StudentService {
    IStudenDao studenDao = new StudentImplDao() ;

    public void deletIdStudent(int id){
        String sql = "DELETE FROM student where id=?" ;
        studenDao.delete(sql,id);
    }
    public void savaStudent(Student student){
        String sql = "INSERT INTO student(name,age) VALUES(?,?)" ;
        studenDao.save(sql,student.getName(),student.getAge());
    }
    public List<Student> studentList(){
       return studenDao.list();
    }
    public void editInfomation(Student student){
        studenDao.editInfomation(student.getId(),student.getName(),student.getAge());

    }
    public Student get(int id){
       return studenDao.get(id);
    }
    public void update(int id ,Student student){
        studenDao.updata(student.getName(),student.getAge(),id);
    }
}
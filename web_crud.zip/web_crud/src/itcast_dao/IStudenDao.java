/**
 * FileName: IStudenDao
 * Author:   10374
 * Date:     2019/7/10 10:17
 * Description: 学生数据接口
 * Version:
 */
package itcast_dao;

import itcast_domain.Student;

import java.util.List;

/**
 * 〈一句话功能简述〉<br>
 * 〈学生数据接口〉
 */
public interface IStudenDao {
    /*
     * 保存指定学生对象
     * */
    void save(String sql ,Object... paramet) ;

    /*
    * 查询所有学生列表
    * */
    List<Student> list() ;
    /*
    * 删除ID
    * */
    void delete(String sql ,int id) ;
    void editInfomation(Object... paramet) ;
    Student get(int id) ;
    void updata(Object... paramet) ;
}
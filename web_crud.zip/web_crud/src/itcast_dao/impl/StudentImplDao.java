/**
 * FileName: StudentImplDao
 * Author:   10374
 * Date:     2019/7/10 10:31
 * Description: 学生功能数据库实现
 * Version:
 */
package itcast_dao.impl;

import itcast_dao.IStudenDao;
import itcast_domain.Student;
import itcast_util.JdbcUtils;
import sun.swing.BakedArrayList;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 * 〈一句话功能简述〉<br> 
 * 〈学生功能数据库实现〉
 */
public class StudentImplDao implements IStudenDao {
    private Connection connection=null ;
    private PreparedStatement preparedStatement = null ;
    private ResultSet resultSet = null ;


    @Override
    public void save(String sql, Object... paramet) {
        connection = JdbcUtils.getConnection() ;
        try {
            preparedStatement = connection.prepareStatement(sql) ;
            for(int index =0;index<paramet.length;index++) {
                preparedStatement.setObject(index+1,paramet[index]);
            }
            preparedStatement.executeUpdate() ;
        } catch (SQLException e) {
            e.printStackTrace();
        }finally {
            JdbcUtils.closeAll(connection,preparedStatement,null);
        }

    }

    @Override
    public List<Student> list() {
        String sql = "SELECT *FROM student" ;
        List<Student> list= new ArrayList() ;
        connection = JdbcUtils.getConnection() ;
        try {
            preparedStatement = connection.prepareStatement(sql) ;
            resultSet = preparedStatement.executeQuery() ;
            while(resultSet.next()){
                Student student = new Student() ;
                list.add(student);
                student.setId((Integer)resultSet.getInt("id"));
                student.setName(resultSet.getString("name"));
                student.setAge((Integer) resultSet.getInt("age"));
            }
            return list ;
        } catch (SQLException e) {
            e.printStackTrace();
        }finally {
            JdbcUtils.closeAll(connection,preparedStatement,resultSet);
        }
        return null;
    }

    @Override
    public void delete(String sql, int id) {
        connection = JdbcUtils.getConnection() ;
        try {
            preparedStatement= connection.prepareStatement(sql) ;
            preparedStatement.setInt(1,id);
            preparedStatement.executeUpdate() ;
        } catch (SQLException e) {
            e.printStackTrace();
        }finally {
            JdbcUtils.closeAll(connection,preparedStatement,null);
        }
    }

    @Override
    public void editInfomation(Object... paramet) {
        String sql = "UPDATE student set name=?,age=? where id=?" ;
        connection = JdbcUtils.getConnection() ;
        try {
            preparedStatement = connection.prepareStatement(sql) ;
            for(int index=0;index<paramet.length;index++){
                preparedStatement.setObject(index+1,paramet[index]);
            }
            preparedStatement.executeUpdate() ;
        } catch (SQLException e) {
            e.printStackTrace();
        }finally {
            JdbcUtils.closeAll(connection,preparedStatement,null);
        }
    }

    @Override
    public Student get(int id) {
        connection = JdbcUtils.getConnection() ;
        String sql = "SELECT *FROM student where id=?" ;
        Student student = new Student() ;
        try {
            preparedStatement = connection.prepareStatement(sql) ;
            preparedStatement.setInt(1,id);
            resultSet =preparedStatement.executeQuery() ;
            while(resultSet.next()){
                student.setName(resultSet.getString("name")) ;
                student.setAge(Integer.valueOf(resultSet.getInt("age")));
                student.setId(resultSet.getInt(id));
            }
            return student ;
        } catch (SQLException e) {
            e.printStackTrace();
        }finally {
            JdbcUtils.closeAll(connection,preparedStatement,resultSet);
        }
        return null;
    }

    @Override
    public void updata(Object... paramet) {
        String sql ="UPDATE student set name=?,age=? WHERE id=?" ;
        connection = JdbcUtils.getConnection() ;
        try {
            preparedStatement = connection.prepareStatement(sql) ;
            for(int index=0;index<paramet.length;index++){
                preparedStatement.setObject(index+1,paramet[index]) ;
            }
            preparedStatement.executeUpdate() ;
        } catch (SQLException e) {
            e.printStackTrace();
        }finally {
            JdbcUtils.closeAll(connection,preparedStatement,null);
        }

    }

}
/**
 * FileName: JdbcUtils
 * Author:   10374
 * Date:     2019/7/10 10:19
 * Description: dbcp数据库连接
 * Version:
 */
package itcast_util;

import org.apache.commons.dbcp.BasicDataSourceFactory;

import javax.sql.DataSource;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;

/**
 * 〈一句话功能简述〉<br> 
 * 〈dbcp数据库连接通用组件〉
 */
public class JdbcUtils {
    private  static DataSource dataSource = null ;
    static {
        try {
            Properties properties = new Properties() ;
           properties.load(Thread.currentThread().getContextClassLoader().getResourceAsStream("dbcp.properties"));
            dataSource = BasicDataSourceFactory.createDataSource(properties);
        }catch (Exception e){
            e.printStackTrace();
        }
    }
    public static Connection getConnection() {
        try {
            return dataSource.getConnection();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return  null ;
    }
    public static void closeAll(Connection connection , Statement statement , ResultSet resultSet){
        if(resultSet !=null){
            try {
                resultSet.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }else if(statement != null){
            try {
                statement.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }else {
            try {
                connection.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
}